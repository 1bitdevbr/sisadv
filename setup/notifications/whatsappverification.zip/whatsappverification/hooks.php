<?php
use WHMCS\Database\Capsule;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

add_hook('ClientAreaPageRegister', 1, function($vars) {
    logActivity('User visited the registration page by hooks.php file');

    // Fetch the secret, account, and colors from the database
    $secretQuery = Capsule::table('mod_zxmessaging_settings')->select('apikey')->first();
    $accountQuery = Capsule::table('mod_zxmessaging_settings')->select('whatsapp')->first();
    
    // Assign the fetched values or use default values if not found
    $secret = $secretQuery->apikey ?? '';
    $account = $accountQuery->whatsapp ?? '';

    // Fetch modal settings (colors and text) from the database
    $modalHeadingColor = Capsule::table('tbladdonmodules')->where('module', 'whatsappverification')->where('setting', 'headingColor')->first();
    $modalParagraphColor = Capsule::table('tbladdonmodules')->where('module', 'whatsappverification')->where('setting', 'paragraphColor')->first();
    $modalButtonColor = Capsule::table('tbladdonmodules')->where('module', 'whatsappverification')->where('setting', 'buttonColor')->first();
    $modalButtonBackgroundColor = Capsule::table('tbladdonmodules')->where('module', 'whatsappverification')->where('setting', 'buttonBgColor')->first();
    $modalContentBackground = Capsule::table('tbladdonmodules')->where('module', 'whatsappverification')->where('setting', 'modalBgColor')->first();

    // Fetch the headings and paragraphs from the database
    $mainHeadingQuery = Capsule::table('tbladdonmodules')->where('module', 'whatsappverification')->where('setting', 'Main Heading')->first();
    $mainParagraphQuery = Capsule::table('tbladdonmodules')->where('module', 'whatsappverification')->where('setting', 'Main Paragraph')->first();
    $otpHeadingQuery = Capsule::table('tbladdonmodules')->where('module', 'whatsappverification')->where('setting', 'OTP Heading')->first();
    $otpParagraphQuery = Capsule::table('tbladdonmodules')->where('module', 'whatsappverification')->where('setting', 'OTP Paragraph')->first();

    // Access the 'value' field to get the colors and text
    $modalBgColor = $modalContentBackground->value;
    $headingColor = $modalHeadingColor->value;
    $paragraphColor = $modalParagraphColor->value;
    $buttonColor = $modalButtonColor->value;
    $buttonBgColor = $modalButtonBackgroundColor->value;

    // Get headings and paragraphs or use default values if not found
    $mainHeading = $mainHeadingQuery->value ?? 'Enter WhatsApp Number';
    $mainParagraph = $mainParagraphQuery->value ?? 'Please enter your valid WhatsApp number to proceed. This number will be used for verification purposes.';
    $otpHeading = $otpHeadingQuery->value ?? 'Enter OTP';
    $otpParagraph = $otpParagraphQuery->value ?? 'We have sent an OTP to your WhatsApp number.';

    // Echoing the HTML, CSS, and JavaScript content to the registration page
    echo <<<HTML
    <!-- Include CSS for intl-tel-input -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/css/intlTelInput.css" />

    <!-- Include JS for intl-tel-input -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/js/intlTelInput.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/js/utils.min.js"></script>

    <style>
        #myModal {
            display: block;
            position: fixed;
            z-index: 1050;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
        }

        #modalContent {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: $modalBgColor;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            width: 400px;
            text-align: center;
            color: $paragraphColor;
        }
        .field-icon {
            margin-top: 10px !important;
        }

        #modalContent h2 {
            font-size: 22px;
            margin-bottom: 10px;
            color: $headingColor;
        }

        #modalContent p {
            font-size: 14px;
            margin-bottom: 20px;
            color: $paragraphColor;
        }

        #phone, #otp {
            width: 100%;
            padding: 10px 14px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            padding-left: 45px;
        }

        #button, #otpSubmitButton {
            padding: 10px 20px;
            background-color: $buttonBgColor;
            color: $buttonColor;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        #closeModalButton {
            padding: 10px 20px;
            background-color: red;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        #button:hover, #otpSubmitButton:hover {
            background-color: #218838;
        }

        .iti, .iti--allow-dropdown {
            width: 100% !important;
            margin-bottom: 10px !important;
        }  
    </style>

    <div id="myModal">
      <div id="modalContent">
        <h2>$mainHeading</h2>
        <p>$mainParagraph</p>
        <form id="whatsappForm" onsubmit="return false;">
          <input id="phone" type="tel" placeholder="7447746669" name="number" required>
          <br />
          <button type="button" id="button">Submit</button>
        </form>
      </div>
    </div>

    <script>

    document.addEventListener("DOMContentLoaded", function() {
      // Initialize intl-tel-input plugin
      var input = document.querySelector("#phone");
      var iti1 = window.intlTelInput(input, {
        initialCountry: "gb",
        geoIpLookup: function(success, failure) {
          fetch("https://ipinfo.io/json?token=0d06d5089b05cd", { mode: 'no-cors' })
            .then(function(resp) { return resp.json(); })
            .catch(function() { return { country: "us" }; })
            .then(function(resp) { success(resp.country); });
        },
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/js/utils.min.js"
      });

      var button = document.getElementById("button");
      var modal = document.getElementById("myModal");

      button.addEventListener("click", function(event) {
        event.preventDefault();

        const phoneNumber = iti1.getNumber();
        const countryData = iti1.getSelectedCountryData();

        // AJAX request to verify the number
        var xhrVerify = new XMLHttpRequest();
        xhrVerify.open("GET", "https://sys.wasms.net/api/validate/whatsapp?secret={$secret}&unique=1725020937b056eb1587586b71e2da9acfe4fbd19e66d1bb09e1bbc&phone=" + encodeURIComponent(phoneNumber), true);

        xhrVerify.onreadystatechange = function() {
          if (xhrVerify.readyState == 4 && xhrVerify.status == 200) {
            var verifyResponse = JSON.parse(xhrVerify.responseText);

            // Check if the number is verified
            if (verifyResponse.status == 200) {
              // Number is verified, now send the OTP
              var xhrSendOTP = new XMLHttpRequest();
              xhrSendOTP.open("POST", "https://sys.wasms.net/api/send/otp", true);
              xhrSendOTP.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

              xhrSendOTP.onreadystatechange = function() {
                if (xhrSendOTP.readyState == 4 && xhrSendOTP.status == 200) {
                  var otpResponse = JSON.parse(xhrSendOTP.responseText);

                  if (otpResponse.status == 200) {
                    // OTP sent, ask user to enter OTP
                    document.getElementById("modalContent").innerHTML = 
                      '<h2>$otpHeading</h2>' +
                      '<p>$otpParagraph</p>' +
                      '<form id="OTPForm" onsubmit="return false;">' +
                      '<input id="otp" type="text" placeholder="Please enter the OTP" name="OTP" required>' +
                      '<button type="button" id="otpSubmitButton">Submit</button>' +
                      '</form>';

                    // Re-bind the event listener for the new button
                    document.getElementById("otpSubmitButton").addEventListener("click", function() {
                      var enteredOtp = document.getElementById("otp").value;
                      var sentOtp = otpResponse.data.otp;

                      if (enteredOtp == sentOtp) {
                        // If OTP is correct, save phone number directly without redirecting

                        // AJAX request to save WhatsApp number in the database
                        var xhrSave = new XMLHttpRequest();
                        xhrSave.open("POST", "", true); // The request is handled by this hook itself
                        xhrSave.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

                        xhrSave.onreadystatechange = function() {
                          if (xhrSave.readyState == 4 && xhrSave.status == 200) {
                            document.getElementById("modalContent").innerHTML = 
                              '<h2>Thank You For WhatsApp Verification</h2>' +
                              '<p>Thank you for verifying your WhatsApp number. You can now proceed with registration.</p>' +
                              '<button type="button" id="closeModalButton">Close</button>';

                            document.getElementById("closeModalButton").addEventListener("click", function() {
                              modal.style.display = "none"; // Close the modal
                            });
                          }
                        };

                        xhrSave.send("action=save_number&phone=" + encodeURIComponent(phoneNumber));
                      } else {
                        alert("The OTP entered is incorrect. Please try again.");
                      }
                    });
                  } else {
                    alert("Failed to send OTP. Please try again.");
                  }
                }
              };

              // Send the OTP POST request with required parameters
              var params = "secret={$secret}"
                          + "&type=whatsapp"
                          + "&message=Your OTP is {{otp}}"
                          + "&phone=" + encodeURIComponent(phoneNumber)
                          + "&expire=5"
                          + "&priority=2"
                          + "&account={$account}"
                          + "&mode=devices";
              xhrSendOTP.send(params);
            } else {
              alert("Invalid WhatsApp number. Please try again.");
            }
          }
        };

        xhrVerify.send(); // Send the verification request
      });
    });
    </script>
HTML;

    // Handle the save number request directly within this hook
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'save_number') {
        logActivity(print_r($_POST, true));
        $phone = $_POST['phone'];
        require 'configuration.php';

        // Database connection details
        $servername = $db_host;
        $username = $db_username;
        $dbPassword = $db_password;
        $database = $db_name;
        logActivity("DB Host: $db_host, Username: $db_username, DB: $db_name");

        // Create a connection to the database
        $conn = new mysqli($servername, $username, $dbPassword, $database);
        // Check connection
        if ($conn->connect_error) {
            logActivity("Connection failed: " . $conn->connect_error);
            die("Connection failed: " . $conn->connect_error);
        } else {
            logActivity("Database connection successful.");
        }

        // Create the table if it doesn't exist
        $tableCreateQuery = "CREATE TABLE IF NOT EXISTS whatsapp_numbers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            phone VARCHAR(255) UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";

        if ($conn->query($tableCreateQuery) === TRUE) {
            logActivity('whatsapp_numbers table created successfully or already exists.');
        } else {
            logActivity('Error creating table: ' . $conn->error);
            die('Error creating table.');
        }

        // Sanitize input to prevent SQL injection
        $phone = $conn->real_escape_string($phone);

        // Check if the phone number already exists in the database
        $sql_check = "SELECT * FROM whatsapp_numbers WHERE phone = '$phone'";
        $result = $conn->query($sql_check);

        if ($result->num_rows > 0) {
            // If the phone number already exists, return a response
            echo "Number already exists in the database.";
        } else {
            // Insert the phone number into the database if it doesn't exist
            $sql_insert = "INSERT INTO whatsapp_numbers (phone) VALUES ('$phone')";

            if ($conn->query($sql_insert) === TRUE) {
                echo "Success";
            } else {
                echo "Error: " . $sql_insert . "<br>" . $conn->error;
            }
        }

        // Close the database connection
        $conn->close();
        exit();
    }
});
?>