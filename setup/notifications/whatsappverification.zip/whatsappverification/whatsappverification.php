<?php
use WHMCS\Database\Capsule;

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

/**
 * whatsappverification Addon Module Configuration
 *
 * @return array
 */
function whatsappverification_config() {
   return [
        'name' => 'WhatsApp Verification Module',
        'description' => 'The WhatsApp Verification Module is designed to integrate WhatsApp-based user verification into the registration process within WHMCS. This module is triggered by the ClientAreaPageRegister hook and prompts users to verify their identity via WhatsApp when registering for an account.',
        'version' => '1.0',
        'author' => 'WaSMS.Net',
        'fields' => []
    ];
}

function whatsappverification_activate() {
    // Define the default settings
    $defaultSettings = [
        ['module' => 'whatsappverification', 'setting' => 'headingColor', 'value' => '#ffffff'],
        ['module' => 'whatsappverification', 'setting' => 'paragraphColor', 'value' => '#f5c32c'],
        ['module' => 'whatsappverification', 'setting' => 'modalBgColor', 'value' => '#0a2029'],
        ['module' => 'whatsappverification', 'setting' => 'buttonColor', 'value' => '#ffffff'],
        ['module' => 'whatsappverification', 'setting' => 'buttonBgColor', 'value' => '#34c759'],
        ['module' => 'whatsappverification', 'setting' => 'Main Heading', 'value' => 'Enter WhatsApp Number'],
        ['module' => 'whatsappverification', 'setting' => 'Main Paragraph', 'value' => 'Please enter your valid WhatsApp number to proceed. This number will be used for verification purposes.'],
        ['module' => 'whatsappverification', 'setting' => 'OTP Heading', 'value' => 'Enter OTP'],
        ['module' => 'whatsappverification', 'setting' => 'OTP Paragraph', 'value' => 'We have sent an OTP to your WhatsApp number.']
    ];

    // Loop through each default setting and insert it if it doesn't exist
    foreach ($defaultSettings as $setting) {
        $existingSetting = Capsule::table('tbladdonmodules')
            ->where('module', $setting['module'])
            ->where('setting', $setting['setting'])
            ->first();

        // If the setting doesn't exist, insert it
        if (!$existingSetting) {
            Capsule::table('tbladdonmodules')->insert($setting);
        }
    }

    return ['status' => 'success', 'description' => 'whatsappverification module activated successfully and default settings have been added.'];
}

function whatsappverification_deactivate() {
    try {
        // Clean up, remove tables, etc.
        return ['status' => 'success', 'description' => 'whatsappverification module deactivated successfully'];
    } catch (Exception $e) {
        return ['status' => 'error', 'description' => 'Unable to deactivate whatsappverification module: ' . $e->getMessage()];
    }
}


function whatsappverification_output($vars) {
    // Fetch saved settings from the database
    $settings = Capsule::table('tbladdonmodules')
        ->where('module', 'whatsappverification')
        ->pluck('value', 'setting'); // This will return key-value pairs (setting => value)

    // Define the default values
    $headingColor = $settings['headingColor'] ?? '#ffffff';
    $paragraphColor = $settings['paragraphColor'] ?? '#f5c32c';
    $modalBgColor = $settings['modalBgColor'] ?? '#0a2029';
    $buttonColor = $settings['buttonColor'] ?? '#ffffff';
    $buttonBgColor = $settings['buttonBgColor'] ?? '#34c759';

    $mainHeading = $settings['Main Heading'] ?? 'Enter WhatsApp Number';
    $mainParagraph = $settings['Main Paragraph'] ?? 'Please enter your valid WhatsApp number to proceed. This number will be used for verification purposes.';
    $otpHeading = $settings['OTP Heading'] ?? 'Enter OTP';
    $otpParagraph = $settings['OTP Paragraph'] ?? 'We have sent an OTP to your WhatsApp number.';

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $headingColor = $_POST['headingColor'];
        $paragraphColor = $_POST['paragraphColor'];
        $modalBgColor = $_POST['modalBgColor'];
        $buttonColor = $_POST['buttonColor'];
        $buttonBgColor = $_POST['buttonBgColor'];

        $mainHeading = $_POST['mainHeading'];
        $mainParagraph = $_POST['mainParagraph'];
        $otpHeading = $_POST['OTPHeading'];
        $otpParagraph = $_POST['OTPParagraph'];

        // Save each setting to the database separately
        $settingsToSave = [
            'headingColor' => $headingColor,
            'paragraphColor' => $paragraphColor,
            'modalBgColor' => $modalBgColor,
            'buttonColor' => $buttonColor,
            'buttonBgColor' => $buttonBgColor,
            'Main Heading' => $mainHeading,
            'Main Paragraph' => $mainParagraph,
            'OTP Heading' => $otpHeading,
            'OTP Paragraph' => $otpParagraph,
        ];

        foreach ($settingsToSave as $setting => $value) {
            Capsule::table('tbladdonmodules')
                ->updateOrInsert(
                    ['module' => 'whatsappverification', 'setting' => $setting],
                    ['value' => $value]
                );
        }

        echo '<div class="alert alert-success">Settings Saved Successfully!</div>';
    }

    // HTML form for input fields with forced default values
    echo '
    <form method="post">
        <div class="form-group">
            <label for="mainHeading">Main Heading</label>
            <input type="text" id="mainHeading" name="mainHeading" class="form-control" value="' . $mainHeading . '" required>
        </div>
        
        <div class="form-group">
            <label for="mainParagraph">Main Description</label>
            <input type="text" id="mainParagraph" name="mainParagraph" class="form-control" value="' . $mainParagraph . '" required>
        </div>
        
        <div class="form-group">
            <label for="OTPHeading">OTP Heading</label>
            <input type="text" id="OTPHeading" name="OTPHeading" class="form-control" value="' . $otpHeading . '" required>
        </div>
        
        <div class="form-group">
            <label for="OTPParagraph">OTP Description</label>
            <input type="text" id="OTPParagraph" name="OTPParagraph" class="form-control" value="' . $otpParagraph . '" required>
        </div>
        
        <div class="form-group">
            <label for="headingColor">Heading Color</label>
            <input type="color" id="headingColor" name="headingColor" class="form-control" value="' . $headingColor . '" required>
        </div>
        
        <div class="form-group">
            <label for="paragraphColor">Description Color</label>
            <input type="color" id="paragraphColor" name="paragraphColor" class="form-control" value="' . $paragraphColor . '" required>
        </div>
        
        <div class="form-group">
            <label for="modalBgColor">Modal Box Background Color</label>
            <input type="color" id="modalBgColor" name="modalBgColor" class="form-control" value="' . $modalBgColor . '" required>
        </div>
        
        <div class="form-group">
            <label for="buttonColor">Button Color</label>
            <input type="color" id="buttonColor" name="buttonColor" class="form-control" value="' . $buttonColor . '" required>
        </div>
        
        <div class="form-group">
            <label for="buttonBgColor">Button Background Color</label>
            <input type="color" id="buttonBgColor" name="buttonBgColor" class="form-control" value="' . $buttonBgColor . '" required>
        </div>
        
        <button type="submit" class="btn btn-primary">Save Settings</button>
    </form>
    
    <div class="text-center">
        <a href="https://wasms.net">Created by WaSMS.Net</a>
    </div>
    ';
}
?>
